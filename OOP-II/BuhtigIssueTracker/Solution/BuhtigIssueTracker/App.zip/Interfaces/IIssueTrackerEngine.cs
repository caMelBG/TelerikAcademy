﻿namespace BuhtigIssueTracker.Interfaces
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}
